package com.servlet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.ayantsoft.coreJava.Employee;

public class ExampleSorting {

	public static void main(String[] args) {
       
		//sort primitives array like int array
       /* int[] intArr = {5,9,1,10};
        Arrays.sort(intArr);
        System.out.println(Arrays.toString(intArr));
        
        //sorting String array
        String[] strArr = {"A", "C", "B", "Z", "E"};
        Arrays.sort(strArr);
        System.out.println(Arrays.toString(strArr));
        
        //sorting list of objects of Wrapper classes
        List<String> strList = new ArrayList<String>();
        strList.add("A");
        strList.add("C");
        strList.add("B");
        strList.add("Z");
        strList.add("E");
        Collections.sort(strList);
        for(String str: strList){
        	System.out.print(" "+str);
        } */
        	
		
		/*Employee[] empArr = new Employee[3];
		
		empArr[0] = new Employee(11, "Somnath",30,40000);
		empArr[1] = new Employee(20, "Arnab", 29, 35000);
		empArr[2] = new Employee(5, "Herojit", 35, 5000);
		
		//sorting employees array using Comparable interface implementation
		Arrays.sort(empArr);
		System.out.println("Default Sorting of Employees list:\n"+Arrays.toString(empArr));
	*/	
		
		
		List<Employee> empArr = new ArrayList<Employee>();
		
		empArr.add(new Employee(11, "Somnath",30,40000));
		empArr.add(new Employee(20, "Arnab", 29, 35000));
		empArr.add(new Employee(5, "Herojit", 35, 5000));
		Collections.sort(empArr);
        for(Employee emp: empArr) {
        	System.out.print(" "+emp);
        }
        	
		
		/*Comparator<Employee> employeeNameComparator = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                return e1.getName().compareTo(e2.getName());
            }
        };
	     
		Collections.sort(empArr,employeeNameComparator);
        for(Employee emp: empArr) System.out.print(" "+emp);
		*/
        //from Java 8 onwards
        
        /*Collections.sort(empArr,Comparator.comparing(Employee::getName).reversed());
        Collections.sort(empArr,Comparator.comparing(Employee::getId).reversed());
        for(Employee emp: empArr) System.out.print(" "+emp);
		*/
		
    }
}
	

